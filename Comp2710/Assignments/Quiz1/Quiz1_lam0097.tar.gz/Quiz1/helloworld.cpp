//this is a test/helloworld
//Lawrence "Alex" Martin
//Quiz1
//Code for HelloWorld 
//No

#include <iostream>
using namespace std; 

int main()
{
cout << "Hello, World!";
cout << endl;
return 0;
}






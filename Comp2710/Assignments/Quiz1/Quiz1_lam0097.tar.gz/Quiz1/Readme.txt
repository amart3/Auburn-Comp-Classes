In "helloworld.cpp" file, please enter proper info in the comments section and upload it to Canvas with a format: Quiz1_username.tar.gz
There must be two files in your Quiz1_username.tar.gz (helloworld.cpp and Readme.txt)

